#include "../win32-msvc2012/qplatformdefs.h"

